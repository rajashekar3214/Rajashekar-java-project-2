package com.dev.task.config;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DBInitializeConfig {

	@Autowired
	private DataSource dataSource;
	
	@PostConstruct
	public void initialize(){
		try {
			// boolean not null default 0)
			Connection connection = dataSource.getConnection();
			Statement statement = connection.createStatement();
			statement.execute("DROP TABLE IF EXISTS MenuItem");
			statement.execute("DROP TABLE IF EXISTS SubMenuItem");
			statement.execute("DROP TABLE IF EXISTS Questions");
			statement.executeUpdate(									
					"CREATE TABLE MenuItem(" +
					"MenuItemID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, " +
					"MenuItemName varchar(555) not null," +
					"Description  varchar(1055))"
					);
					// statement.executeUpdate(
					// 	"INSERT INTO Categories " +
					// 	"(MenuItemName,Description) " +
					// 	"VALUES " + "('Computer Science', 'Computer Science MenuItem')"
					// 	);
			statement.executeUpdate(									
				"CREATE TABLE SubMenuItem(" +
				"SubMenuItemID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, " +
				"MenuItemID INTEGER NOT NULL," +
				"SubMenuItemName  varchar(1055) NOT NULL,"+
				"Description  varchar(1055))"
				);
				// statement.executeUpdate(
				// 		"INSERT INTO SubCategories " +
				// 		"(MenuItemID, SubMenuItemName ,Description) " +
				// 		"VALUES " + "(1,'Java Test For Beginners', 'Java Test avail for testing your skill')"
				// 		);
				statement.executeUpdate(									
				"CREATE TABLE Questions(" +
				"QuestionID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, " +
				"SubMenuItemID INTEGER NOT NULL," +
				"Question  varchar(1055) NOT NULL,"+
				"Option1  varchar(1055) NOT NULL,"+
				"Option2  varchar(1055) NOT NULL,"+
				"Option3  varchar(1055),"+
				"Option4  varchar(1055),"+
				"Answer  varchar(1055) NOT NULL )" 
				);
				// statement.executeUpdate(
				// 		"INSERT INTO Question " +
				// 		"(SubMenuItemID, Question ,Option1,Option2, Option3,Option4,Answer) " +
				// 		"VALUES " + "(1,'What is spring in java technology?', 'Framework', 'Security Class', 'Math Related Libarary', 'Polymorphisam', 'Framework')"
				// 		);				
			
			statement.close();
			connection.close();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
