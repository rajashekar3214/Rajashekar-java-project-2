package com.dev.task.repo;

import org.springframework.data.repository.CrudRepository;
import java.util.List;

import com.dev.task.entity.Question;

public interface QuestionRepository extends CrudRepository<Question, Integer>{	
	Question findQuestionByName(String name);
	List<Question> findAllById(Integer Id);
}
