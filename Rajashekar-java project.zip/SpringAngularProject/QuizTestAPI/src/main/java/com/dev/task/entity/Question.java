package com.dev.task.entity;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModelProperty;

@Entity
@Table(name = "Questions")
public class Question {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@ApiModelProperty(notes = "The database generated task ID")
    private Integer QuestionID;    
	@ApiModelProperty(notes = "The database generated task ID", required = true)
	private Integer SubMenuItemID;
	@ApiModelProperty(notes = "The task name", required = true)
	private String QuestionName;
	@ApiModelProperty(notes = "The task Option1", required = true)
    private String Option1;
    @ApiModelProperty(notes = "The task Option1", required = true)
    private String Option2;
    @ApiModelProperty(notes = "The task Option1")
    private String Option3;
    @ApiModelProperty(notes = "The task Option1")
    private String Option4;
    @ApiModelProperty(notes = "The task Option1", required = true)
	private String Answer;
	public Integer getQuestionID() {
		return QuestionID;
	}
	public void setQuestionID(Integer id) {
		this.QuestionID = id;
    }
    public Integer getSubMenuItemID() {
		return SubMenuItemID;
	}
	public void setSubMenuItemID(Integer SubMenuItemID) {
		this.SubMenuItemID = SubMenuItemID;
	}
	public String getQuestionName() {
		return QuestionName;
	}
	public void setQuestionName(String name) {
		this.QuestionName = name;
	}
	public String getOption1() {
		return Option1;
	}
	public void setOption1(String option1) {
		this.Option1 = option1;
    }
    public String getOption2() {
		return Option2;
	}
	public void setOption2(String option2) {
		this.Option2 = option2;
    }
    public String getOption3() {
		return Option3;
	}
	public void setOption3(String option3) {
		this.Option3 = option3;
    }
    public String getOption4() {
		return Option4;
	}
	public void setOption4(String option4) {
		this.Option4 = option4;
    }
    public String getAnswer() {
		return Answer;
	}
	public void setAnswer(String answer) {
		this.Answer = answer;
    }    

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
			Question other = (Question) obj;
		if (QuestionName == null) {
			if (other.QuestionName != null)
				return false;
		} else if (!QuestionName.equals(other.QuestionName))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Task [QuestionID=" + QuestionID + ", QuestionName=" + QuestionName + ", Description=" + Answer + "]";
	}
	

}
