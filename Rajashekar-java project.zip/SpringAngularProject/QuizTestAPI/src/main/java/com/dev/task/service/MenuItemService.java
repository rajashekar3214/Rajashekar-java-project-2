package com.dev.task.service;

import java.util.List;

import com.dev.task.entity.MenuItem;

public interface MenuItemService {

	public MenuItem saveOrUpdateTask(MenuItem task);
	public MenuItem getTask(Integer id);
	public void removeTask(Integer id);
	public List<MenuItem> getTasks();  
	public boolean isTaskExist(MenuItem task);
	
	
}
