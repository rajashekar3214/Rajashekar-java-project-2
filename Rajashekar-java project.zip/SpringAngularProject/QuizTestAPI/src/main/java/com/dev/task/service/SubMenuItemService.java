package com.dev.task.service;

import java.util.List;

import com.dev.task.entity.SubMenuItem;

public interface SubMenuItemService {

	public SubMenuItem saveOrUpdateTask(SubMenuItem task);
	public SubMenuItem getTask(Integer id);
	public void removeTask(Integer id);
	public List<SubMenuItem> getTasks();  
	public boolean isTaskExist(SubMenuItem task);
	
	
}
