package com.dev.task.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dev.task.entity.Question;
import com.dev.task.repo.QuestionRepository;
import com.dev.task.service.QuestionService;

@Service
public class QuestionServiceImpl implements QuestionService {

	@Autowired
	private QuestionRepository questionRepository;
	
	@Override
	public Question saveOrUpdateQuestion(Question task) {
		return questionRepository.save(task);
	}

	@Override
	public Question getQuestionById(Integer id) {
		return questionRepository.findOne(id);
    }
    @Override
	public List<Question> getQuestionsListById(Integer id) {
		return questionRepository.findAllById(id);
	}

	@Override
	public void removeQuestion(Integer id) {
		questionRepository.delete(id);
	}

	@Override
	public List<Question> getAllQuestions() {
		return (List<Question>) questionRepository.findAll();
	}

	@Override
	public boolean isQuestionExist(Question question) {
		return questionRepository.findQuestionByName(question.getQuestionName()) != null;
	}
	
	
}
