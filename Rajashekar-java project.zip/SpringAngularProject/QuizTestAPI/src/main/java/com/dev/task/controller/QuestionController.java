package com.dev.task.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.dev.task.entity.Question;
import com.dev.task.service.QuestionService;
import com.dev.task.util.CustomErrorType;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/question")
@CrossOrigin(origins = {"http://localhost:4200"})
@Api(description="Operations pertaining to tasks in Task Management System")
public class QuestionController {
	
	@Autowired	
    private QuestionService questionService;
    
	//------------------- Questions Crud opration ---------------------------

	@RequestMapping(value = "/savequestion",method = RequestMethod.POST)
	@ApiOperation(value = "Create a new question")
	public ResponseEntity<?> createQuestion(@RequestBody Question task) {
		
		if (questionService.isQuestionExist(task)) {
			return new ResponseEntity(new CustomErrorType("Unable to create SubMenuItem. "
					+ "A task with name " + task.getQuestionName() + " already exist"), HttpStatus.CONFLICT);
		}		
		questionService.saveOrUpdateQuestion(task);
		return new ResponseEntity<String>("Task saved successfully", HttpStatus.CREATED);
	}
	
	@RequestMapping(value = "/allquestions",method = RequestMethod.GET)
	@ApiOperation(value = "View a list of available questions")
	public ResponseEntity<List<Question>> getAllQuestions(){
		
		List<Question> tasks = questionService.getAllQuestions();
		if (tasks.isEmpty()){
			return new ResponseEntity(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<List<Question>>(tasks, HttpStatus.OK);
		
	}
	@RequestMapping(value = "/allquestions/{id}",method = RequestMethod.GET)
	@ApiOperation(value = "View a list of available questions by subMenuItem")
	public ResponseEntity<List<Question>> getAllQuestionsBySubMenuItem(Integer id){
		
		List<Question> tasks = questionService.getQuestionsListById(id);
		if (tasks.isEmpty()){
			return new ResponseEntity(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<List<Question>>(tasks, HttpStatus.OK);
		
	}
	
	@RequestMapping(value = "/getquestion/{id}", method = RequestMethod.GET)
	@ApiOperation(value = "Get a question")
	public ResponseEntity<?> getQuestion(@PathVariable("id") Integer id){

		Question task = questionService.getQuestionById(id);
		if (task == null) {
			return new ResponseEntity<>(new CustomErrorType("Task with id " + id
					+ " not found"), HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Question>(task, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/updatequestion/{id}", method = RequestMethod.PUT)
	@ApiOperation(value = "Update a question")
	public ResponseEntity<?> updateQuestion(@PathVariable("id") Integer id, @RequestBody Question task) {
		
		Question currentTask = questionService.getQuestionById(id);
		if (currentTask == null) {
			return new ResponseEntity(new CustomErrorType("Unable to update. User with id " 
					+ id +" not found"), HttpStatus.NOT_FOUND);
		}
		currentTask.setQuestionID(task.getQuestionID());
		currentTask.setSubMenuItemID(task.getSubMenuItemID());
		currentTask.setQuestionName(task.getQuestionName());
		currentTask.setOption1(task.getOption1());
		currentTask.setOption2(task.getOption2());
		currentTask.setOption3(task.getOption3());
		currentTask.setOption4(task.getOption4());
		currentTask.setAnswer(task.getAnswer());

		questionService.saveOrUpdateQuestion(currentTask);
		return new ResponseEntity<Question>(currentTask, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/deletequestion/{id}", method = RequestMethod.DELETE)
	@ApiOperation(value = "Delete a question")
	public ResponseEntity<?> deleteQuestion(@PathVariable("id") Integer id) {
		
		Question task = questionService.getQuestionById(id);
		if (task == null) {
			return new ResponseEntity(new CustomErrorType("Unable to delete. "
					+ "User with id " + id +" not found"), HttpStatus.NOT_FOUND);
		}
		questionService.removeQuestion(id);
		return new ResponseEntity<Question>(HttpStatus.NO_CONTENT);
	}
}
