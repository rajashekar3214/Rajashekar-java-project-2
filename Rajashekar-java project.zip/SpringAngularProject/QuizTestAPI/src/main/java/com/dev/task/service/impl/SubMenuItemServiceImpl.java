package com.dev.task.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dev.task.entity.SubMenuItem;
import com.dev.task.repo.SubMenuItemRepository;
import com.dev.task.service.SubMenuItemService;

@Service
public class SubMenuItemServiceImpl implements SubMenuItemService {

	@Autowired
	private SubMenuItemRepository subMenuItemRepository;
	
	@Override
	public SubMenuItem saveOrUpdateTask(SubMenuItem task) {
		return subMenuItemRepository.save(task);
	}

	@Override
	public SubMenuItem getTask(Integer id) {
		return subMenuItemRepository.findOne(id);
	}

	@Override
	public void removeTask(Integer id) {
		subMenuItemRepository.delete(id);
	}

	@Override
	public List<SubMenuItem> getTasks() {
		return (List<SubMenuItem>) subMenuItemRepository.findAll();
	}

	@Override
	public boolean isTaskExist(SubMenuItem subMenuItem) {
		return subMenuItemRepository.findSubMenuItemByName(subMenuItem.getSubMenuItemName()) != null;
	}
	
	
}
