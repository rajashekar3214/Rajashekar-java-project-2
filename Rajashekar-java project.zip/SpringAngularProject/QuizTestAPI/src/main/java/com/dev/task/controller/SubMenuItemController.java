package com.dev.task.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.dev.task.entity.SubMenuItem;
import com.dev.task.service.SubMenuItemService;
import com.dev.task.util.CustomErrorType;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/SubMenuItem")
@CrossOrigin(origins = {"http://localhost:4200"})
@Api(description="Operations pertaining to tasks in Task Management System")
public class SubMenuItemController {
	
	@Autowired	
	private SubMenuItemService subMenuItemService;

	//------------------------ SubCategories Crud Opration ------------------------

	@RequestMapping(value = "/savesubMenuItem",method = RequestMethod.POST)
	@ApiOperation(value = "Create a new MenuItem")
	public ResponseEntity<?> createSubMenuItem(@RequestBody SubMenuItem task) {
		
		if (subMenuItemService.isTaskExist(task)) {
			return new ResponseEntity(new CustomErrorType("Unable to create SubMenuItem. "
					+ "A task with name " + task.getSubMenuItemName() + " already exist"), HttpStatus.CONFLICT);
		}		
		subMenuItemService.saveOrUpdateTask(task);
		return new ResponseEntity<String>("Task saved successfully", HttpStatus.CREATED);
	}
	
	@RequestMapping(value = "/SubMenuItems",method = RequestMethod.GET)
	@ApiOperation(value = "View a list of available SubMenuItems")
	public ResponseEntity<List<SubMenuItem>> getAllSubMenuItems(){
		
		List<SubMenuItem> tasks = subMenuItemService.getTasks();
		if (tasks.isEmpty()){
			return new ResponseEntity(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<List<SubMenuItem>>(tasks, HttpStatus.OK);
		
	}

	@RequestMapping(value = "/subMenuItem/{id}", method = RequestMethod.GET)
	@ApiOperation(value = "Get a subMenuItem")
	public ResponseEntity<?> getTask(@PathVariable("id") Integer id){

		SubMenuItem task = subMenuItemService.getTask(id);
		if (task == null) {
			return new ResponseEntity<>(new CustomErrorType("Task with id " + id
					+ " not found"), HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<SubMenuItem>(task, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/updatesubMenuItem/{id}", method = RequestMethod.PUT)
	@ApiOperation(value = "Update a MenuItem")
	public ResponseEntity<?> updateSubMenuItem(@PathVariable("id") Integer id, @RequestBody SubMenuItem task) {
		
		SubMenuItem currentTask = subMenuItemService.getTask(id);
		if (currentTask == null) {
			return new ResponseEntity(new CustomErrorType("Unable to update. User with id " 
					+ id +" not found"), HttpStatus.NOT_FOUND);
		}
		currentTask.setSubMenuItemID(task.getSubMenuItemID());
		currentTask.setMenuItemID(task.getMenuItemID());
		currentTask.setSubMenuItemName(task.getSubMenuItemName());
		currentTask.setDescription(task.getDescription());
		subMenuItemService.saveOrUpdateTask(currentTask);
		return new ResponseEntity<SubMenuItem>(currentTask, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/deletesubMenuItem/{id}", method = RequestMethod.DELETE)
	@ApiOperation(value = "Delete a subMenuItem")
	public ResponseEntity<?> deleteSubMenuItem(@PathVariable("id") Integer id) {
		
		SubMenuItem task = subMenuItemService.getTask(id);
		if (task == null) {
			return new ResponseEntity(new CustomErrorType("Unable to delete. "
					+ "User with id " + id +" not found"), HttpStatus.NOT_FOUND);
		}
		subMenuItemService.removeTask(id);
		return new ResponseEntity<SubMenuItem>(HttpStatus.NO_CONTENT);
	}	
}
