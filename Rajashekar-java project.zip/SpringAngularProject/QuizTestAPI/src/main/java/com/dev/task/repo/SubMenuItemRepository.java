package com.dev.task.repo;

import org.springframework.data.repository.CrudRepository;


import com.dev.task.entity.SubMenuItem;
// import com.dev.task.entity.Question;

public interface SubMenuItemRepository extends CrudRepository<SubMenuItem, Integer>{	
	SubMenuItem findSubMenuItemByName(String name);
	// Question findQuestionByName(String name);
}
