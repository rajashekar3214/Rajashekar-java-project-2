package com.dev.task.repo;

import org.springframework.data.repository.CrudRepository;

import com.dev.task.entity.MenuItem;
// import com.dev.task.entity.SubMenuItem;
// import com.dev.task.entity.Question;

public interface MenuItemRepository extends CrudRepository<MenuItem, Integer>{

	MenuItem findMenuItemByName(String name);
	// SubMenuItem findSubMenuItemByName(String name);
	// Question findQuestionByName(String name);
}
