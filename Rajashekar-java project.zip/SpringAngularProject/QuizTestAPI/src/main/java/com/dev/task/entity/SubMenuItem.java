package com.dev.task.entity;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModelProperty;

@Entity
@Table(name = "SubCategories")
public class SubMenuItem {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@ApiModelProperty(notes = "The database generated task ID")
    private Integer SubMenuItemID;    
	@ApiModelProperty(notes = "The database generated task ID", required = true)
	private Integer MenuItemID;
	@ApiModelProperty(notes = "The task name", required = true)
	private String SubMenuItemName;
	@ApiModelProperty(notes = "The task description")
	private String Description;
	public Integer getSubMenuItemID() {
		return SubMenuItemID;
	}
	public void setSubMenuItemID(Integer id) {
		this.SubMenuItemID = id;
    }
    public Integer getMenuItemID() {
		return MenuItemID;
	}
	public void setMenuItemID(Integer MenuItemId) {
		this.MenuItemID = MenuItemId;
	}
	public String getSubMenuItemName() {
		return SubMenuItemName;
	}
	public void setSubMenuItemName(String name) {
		this.SubMenuItemName = name;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String Description) {
		this.Description = Description;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
			SubMenuItem other = (SubMenuItem) obj;
		if (SubMenuItemName == null) {
			if (other.SubMenuItemName != null)
				return false;
		} else if (!SubMenuItemName.equals(other.SubMenuItemName))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Task [SubMenuItemID=" + SubMenuItemID + ", SubMenuItemName=" + SubMenuItemName + ", Description=" + Description + "]";
	}
	

}
