package com.dev.task.entity;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import io.swagger.annotations.ApiModelProperty;

@Entity
@Table(name = "MenuItems")
public class MenuItem {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@ApiModelProperty(notes = "The database generated task ID")
	private Integer MenuItemID;
	@ApiModelProperty(notes = "The task name", required = true)
	private String MenuItemName;
	@ApiModelProperty(notes = "The task description")
	private String Description;
	public Integer getMenuItemID() {
		return MenuItemID;
	}
	public void setMenuItemID(Integer id) {
		this.MenuItemID = id;
	}
	public String getMenuItemName() {
		return MenuItemName;
	}
	public void setMenuItemName(String name) {
		this.MenuItemName = name;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String Description) {
		this.Description = Description;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
			MenuItem other = (MenuItem) obj;
		if (MenuItemName == null) {
			if (other.MenuItemName != null)
				return false;
		} else if (!MenuItemName.equals(other.MenuItemName))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Task [MenuItemID=" + MenuItemID + ", MenuItemName=" + MenuItemName + ", Description=" + Description + "]";
	}
	

}
