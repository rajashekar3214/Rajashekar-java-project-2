package com.dev.task.service;

import java.util.List;

import com.dev.task.entity.Question;;

public interface QuestionService {

    public Question saveOrUpdateQuestion(Question task);
    public Question getQuestionById(Integer id);
	public List<Question> getQuestionsListById(Integer id);
	public void removeQuestion(Integer id);
	public List<Question> getAllQuestions();  
	public boolean isQuestionExist(Question task);
	
	
}
