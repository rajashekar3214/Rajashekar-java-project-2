package com.dev.task.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dev.task.entity.MenuItem;
import com.dev.task.repo.MenuItemRepository;
import com.dev.task.service.MenuItemService;

@Service
public class MenuItemServiceImpl implements MenuItemService {

	@Autowired
	private MenuItemRepository MenuItemRepository;
	
	@Override
	public MenuItem saveOrUpdateTask(MenuItem task) {
		return MenuItemRepository.save(task);
	}

	@Override
	public MenuItem getTask(Integer id) {
		return MenuItemRepository.findOne(id);
	}

	@Override
	public void removeTask(Integer id) {
		MenuItemRepository.delete(id);
	}

	@Override
	public List<MenuItem> getTasks() {
		return (List<MenuItem>) MenuItemRepository.findAll();
	}

	@Override
	public boolean isTaskExist(MenuItem MenuItem) {
		return MenuItemRepository.findMenuItemByName(MenuItem.getMenuItemName()) != null;
	}
	
	
}
