package com.dev.task.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.dev.task.entity.MenuItem;
import com.dev.task.service.MenuItemService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("/MenuItem")
@CrossOrigin(origins = {"http://localhost:4200"})
@Api(description="Operations pertaining to tasks in Task Management System")
public class MenuItemController {
	
	@Autowired
	private MenuItemService MenuItemService;	

	@RequestMapping(value = "/MenuItems",method = RequestMethod.GET)
	@ApiOperation(value = "View a list of available MenuItems")
	public ResponseEntity<List<MenuItem>> getMenuItems(){
		
		List<MenuItem> tasks = MenuItemService.getTasks();
		if (tasks.isEmpty()){
			return new ResponseEntity(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<List<MenuItem>>(tasks, HttpStatus.OK);
		
	}
}
