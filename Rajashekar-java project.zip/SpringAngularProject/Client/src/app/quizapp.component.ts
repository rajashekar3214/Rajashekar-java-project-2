import { Component, OnInit, ViewChild } from '@angular/core';
import { Observable } from 'rxjs';
import { ModalDirective } from 'ngx-bootstrap';
import { TestQuestionClass, SubMenuItemClass, LoginClass, MenuItemClass } from './TestQuestion-class';
import { ToastrService } from 'ngx-toastr';
import { AppService} from './app.service';



 @Component({
	 selector: 'app-root',
	 templateUrl: './quizapp.component.html',
	 styleUrls: ['./quizapp.component.css']
 })
export class QuizAppComponent implements OnInit {
isTestQuestionCardShow = false;
isSubMenuItemShow = true;
validUser = false;
subMenuItems = [];
totalAnswered = 0;
rightAnswer;
statusTestQuestion = 'Add TestQuestion';
TestQuestionObj = new TestQuestionClass();
subMenuItemObj = new SubMenuItemClass();
loginObj = new LoginClass();
@ViewChild('submitModal') submitModal: ModalDirective;
@ViewChild('addTestQuestionModal') addTestQuestionModal : ModalDirective;
@ViewChild('addSubMenuItemModal') addSubMenuItemModal : ModalDirective;
@ViewChild('loginModal') loginModal : ModalDirective;
@ViewChild('loginForm') loginForm: any;
@ViewChild('answerModal') answerModal : ModalDirective;
@ViewChild('TestQuestionForm') TestQuestionForm: any;
@ViewChild('subMenuItemForm') subMenuItemForm: any;
@ViewChild('TestQuestionTest') TestQuestionTest : any;

constructor( private toastr: ToastrService, private apiService: AppService) { }

answerArray = [];
MenuItems = [];
subMenuItemsList = [{"id": 1,'subMenuItemName':"Development"},
{"id": 2,'subMenuItemName':"Database"},
{"id": 3,'subMenuItemName':"Operating System"},
{"id": 4,'subMenuItemName':"Artificial Intelligence"},
{"id": 5,'subMenuItemName':"Binary Logic"}];
	allTestQuestions: any = [{
		"id": 1,
		"TestQuestion": "What is the Spring in Java?",
		"a": "Framework",
		"b": "Scurity Class",
		"c": "Math Related Class",
		"d": "Compiler",
		"answer": "a"
	},
	{
		"id": 2,
		"TestQuestion": "What is toString in Java ?",
		"a": "Class",
		"b": "Variable",
		"c": "Method",
		"d": "None of them",
		"answer": "c"
	},
	{
		"id": 3,
		"TestQuestion": "Can we get repository Method directly without Implementation?",
		"a": "Yes",
		"b": "No",
		"c": "May be",
		"d": "Yes but some",
		"answer": "b"
	}
	];
	
	allSubMenuItems: any = [{
		"MenuItemName":"Development",
		"subMenuItem" : "Java",
		"id": 1,
		"subMenuItemDes": "Java relavient TestQuestion",
	},
	{
		"MenuItemName":"Development",
		"subMenuItem" : "JavaScript",
		"id": 2,
		"subMenuItemDes": "JavaScript relavient TestQuestion",
	},
	{
		"MenuItemName":"Development",
		"subMenuItem" : "Python",
		"id": 3,
		"subMenuItemDes": "Python relavient TestQuestion",
	},
	{
		"MenuItemName":"Database",
		"subMenuItem" : "Mysql",
		"id": 4,
		"subMenuItemDes": "Mysql relavient TestQuestion",
	},
	{
		"MenuItemName":"Database",
		"subMenuItem" : "NoSql",
		"id": 5,
		"subMenuItemDes": "NoSql relavient TestQuestion",
	},
	{
		"MenuItemName":"Database",
		"subMenuItem" : "MongoDB",
		"id": 6,
		"subMenuItemDes": "MongoDB relavient TestQuestion",
	},{
		"MenuItemName":"Database",
		"subMenuItem" : "GraphQL",
		"id": 7,
		"subMenuItemDes": "GraphQL relavient TestQuestion",
	},
	{
		"MenuItemName":"Database",
		"subMenuItem" : "SQLServer",
		"id": 8,
		"subMenuItemDes": "SQLServer relavient TestQuestion",
	},
	{
		"MenuItemName":"Operating System",
		"subMenuItem" : "Linix",
		"id": 9,
		"subMenuItemDes": "Linix relavient TestQuestion",
	},{
		"MenuItemName":"Operating System",
		"subMenuItem" : "Window",
		"id": 10,
		"subMenuItemDes": "Window relavient TestQuestion",
	},
	{
		"MenuItemName":"Operating System",
		"subMenuItem" : "Kali Linex",
		"id": 11,
		"subMenuItemDes": "Kali Linex relavient TestQuestion",
	},
	{
		"MenuItemName":"Operating System",
		"subMenuItem" : "Mac OS",
		"id": 12,
		"subMenuItemDes": "Mac OS Table relavient TestQuestion",
	},{
		"MenuItemName":"Artificial Intelligence",
		"subMenuItem" : "Deep Learning",
		"id": 13,
		"subMenuItemDes": "Deep Learning relavient TestQuestion",
	},
	{
		"MenuItemName":"Artificial Intelligence",
		"subMenuItem" : "Robotics",
		"id": 14,
		"subMenuItemDes": "Robotics relavient TestQuestion",
	},
	{
		"MenuItemName":"Artificial Intelligence",
		"subMenuItem" : "Algorithmic",
		"id": 15,
		"subMenuItemDes": "Algorithmic relavient TestQuestion",
	}
	];

	/**Method call on submit the test */
	submitTest() {
		this.rightAnswer = 0;
		this.totalAnswered = 0;
		for (let i = 0; i < this.allTestQuestions.length; i++) {
			if ("selected" in this.allTestQuestions[i] && (this.allTestQuestions[i]["selected"] != null)) {
				this.totalAnswered++;
				if (this.allTestQuestions[i]["selected"] == this.allTestQuestions[i]["answer"]) {
					this.rightAnswer++;
				}
			}
		}
		this.submitModal.show();

	}
  /**Method call on start the test */
	startQuiz() {
		this.isSubMenuItemShow = true;
		for (let i = 0; i < this.allTestQuestions.length; i++) {
			if ("selected" in this.allTestQuestions[i]) {
				delete this.allTestQuestions[i]["selected"];
			}
		}
		if(this.TestQuestionTest !==undefined) {
			this.TestQuestionTest.reset();
		}
		this.isTestQuestionCardShow = true;

	}
	/**Method call on change category */
    showSubMenuItem(category) {
		this.HomePage();
		this.subMenuItems = this.allSubMenuItems.filter((listing: any) => listing.MenuItemName === category);
	}

	HomePage() {
		this.isSubMenuItemShow = false;
		this.isTestQuestionCardShow = false;
	}
	addTestQuestion() {
		this.statusTestQuestion = 'Add TestQuestion';
		this.addTestQuestionModal.show();
	}
	addSubMenuItem() {
		this.addSubMenuItemModal.show();
	}
	login() {
		this.loginModal.show();
	}
	closeLoginModal() {
		this.loginForm.reset();
		this.loginModal.hide();	
	}
	submitLogin() {
		this.validUser = true;
		this.loginModal.hide();	
	}
	
   closeTestQuestionModal() {
	this.TestQuestionForm.reset();
	this.addTestQuestionModal.hide();
	 }
	 closeSubMenuItemModal() {
		 this.subMenuItemForm.reset();
		 this.addSubMenuItemModal.hide();
	 }
	 updateTestQuestion(id) {
		 debugger;
		 this.statusTestQuestion = 'Update TestQuestion';
		this.TestQuestionObj = JSON.parse(JSON.stringify(this.allTestQuestions.filter((listing: any) => listing.id === id)[0]));
		this.addTestQuestionModal.show();
	 }
	 deleteTestQuestion(id) {
		this.allTestQuestions = this.allTestQuestions.filter((listing: any) => listing.id !== id);
		this.toastr.success('TestQuestion Deleted Successfully!');
	 }

	submitAddTestQuestion() {
		let quesTemp = JSON.parse(JSON.stringify(this.TestQuestionObj));
		quesTemp["id"] = this.allTestQuestions.length + 1;
		this.allTestQuestions.push(quesTemp);
		this.TestQuestionForm.reset();
		this.toastr.success("TestQuestion Added Successfully!!");
		this.addTestQuestionModal.hide();

	}
	checkAnswers() {
		this.submitModal.hide();
		this.answerModal.show();
	}
	ngOnInit() {
		 this.MenuItems = [ {'menuItemID': 1, 'MenuItemName': 'Development'},
		    {'menuItemID': 2, 'MenuItemName': 'Database'},
		    {'menuItemID': 3, 'MenuItemName': 'Operating System'},
		    {'menuItemID': 4, 'MenuItemName': 'Artificial Intelligence'},
		    {'menuItemID': 5, 'MenuItemName': 'Binary Logic'} ];

	
     this.showSubMenuItem('Development');
	}
}
