import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { QuizAppComponent } from './quizapp.component';
import { AccordionModule } from 'ngx-bootstrap';
import { FormsModule } from '@angular/forms';
import { ModalModule } from 'ngx-bootstrap/modal';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import { AppService } from './app.service';
import {
  MatButtonModule, MatCardModule, MatDialogModule, MatTableModule,
  MatToolbarModule, MatMenuModule, MatIconModule, MatProgressSpinnerModule,
  MatAutocompleteModule, MatInputModule, MatSelectModule, MatSidenavModule,
  MatListModule
} from '@angular/material';



@NgModule({
  declarations: [
    QuizAppComponent
  ],
  imports: [
    HttpClientModule,
     MatButtonModule, MatCardModule, MatDialogModule, MatTableModule, MatListModule,
     MatToolbarModule, MatMenuModule, MatIconModule, MatProgressSpinnerModule,
     MatAutocompleteModule, MatInputModule, MatSelectModule, MatSidenavModule,
    ModalModule.forRoot(),
    BrowserAnimationsModule,
    ToastrModule.forRoot(),
  AccordionModule.forRoot(),
    BrowserModule,
    FormsModule
  ],
  providers: [AppService],
  bootstrap: [QuizAppComponent]
})
export class AppModule { }
