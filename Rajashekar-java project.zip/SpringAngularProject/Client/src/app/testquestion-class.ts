export class TestQuestionClass {
    "id" ?: number;
    "TestQuestion": string;
    "a": string;
    "b": string;
    "c": string;
    "d": string;
    "answer": string;
    "selected" ?: string;
    "menuItem": number
    "subMenuItem": number
}
export class MenuItemClass {
    "menuItemID" : number;
    "MenuItemName": string;
}
export class SubMenuItemClass {
    "menuItemID" : number;
    "subMenuItemName": string;
    "subCategoryDes": string;
}
export class LoginClass {
    "userName" : string;
    "password": string;
}

